from fisd_commands_factory import CommandsFactory
import os, subprocess, time

def parse_quotas(s, quota):
    quota_start_index = s.find(quota)
    if quota_start_index == 0:
        quota_end_index = s.rfind(quota)
        if quota_end_index > quota_start_index:
            return s[quota_start_index + 1: quota_end_index]
    return s

def parse_string( s ):
    s = s.lstrip().rstrip()
    s = parse_quotas(s, '"')
    s = parse_quotas(s, "'")
    return [s, 0]

def raise_create_cmd_syntax_error(cls, arguments):
    raise SyntaxError("Invalid {0} : '{1}'. Valid usage is : '{2}'"
                  .format(cls.command_name,
                          arguments,
                          CommandsFactory.get_property(cls.command_name, 'usage')))

def run_cmd_as_admin(command, timeout = 0, hide = False ):
    hiden_output_file_name = "hiden_output.out"
    std_out_file = None
    if hide == True:
        std_out_file = open(hiden_output_file_name, "w", 0)
        process = subprocess.Popen(command, shell=True, stdout=std_out_file, stderr=std_out_file)
    else:
        process = subprocess.Popen(command, shell=True)
    if timeout > 0:
        time.sleep(timeout)
        p = subprocess.Popen("TASKKILL /F /PID {pid} /T".format(pid=process.pid),
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
        p.wait()
    else:
        process.wait()

    if std_out_file:
        std_out_file.close()
        os.remove(hiden_output_file_name)
