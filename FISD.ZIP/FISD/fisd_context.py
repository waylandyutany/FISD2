import os, math
import datetime
variable_mark = '$'

def Decimal(str):
   return int(str)

safe_eval_dict = {'acos': math.acos, 'asin': math.asin, 'atan': math.atan, 'atan2': math.atan2, 'ceil': math.ceil, 'cos': math.cos,
             'cosh': math.cosh, 'degrees': math.degrees, 'e': math.e, 'exp': math.exp, 'abs': abs, 'fabs': math.fabs,
             'floor': math.floor, 'fmod': math.fmod, 'frexp': math.frexp, 'hypot': math.hypot, 'ldexp': math.ldexp,
             'log': math.log,
             'log10': math.log10, 'modf': math.modf, 'pi': math.pi, 'pow': pow, 'radians': math.radians,
             'sin': math.sin,
             'sinh': math.sinh, 'sqrt': math.sqrt, 'tan': math.tan, 'tanh': math.tanh,
             'str': str, 'int' : int, 'float' : float, 'Decimal' : Decimal,'datetime':datetime }

class Context(object):

    def __init__(self, logger):
        self.__logger = logger
        self.__variables = {}
        self.__execution_stack = []
        self.__execution_result = None
        self.__for_loops = []
        #!!! this need to bu pushed when commands are executing !!!
        self.__execution_commands = []
        self.__execution_index = 0
        #!!! Dont forget to add new execution related stuff to __push_commands and __pop_commands !!!

    def __push_commands(self, commands):
        self.__execution_stack.append([self.__execution_commands, self.__execution_index])
        self.__execution_commands = commands
        self.__execution_index = 0

    def __pop_commands(self):
        self.__execution_commands, self.__execution_index = self.__execution_stack.pop()

########################################################################################################################
########################################################################################################################
    def for_loop(self, variable_name, from_value, to_value, step_value):
        self.__for_loops.append({'variable_name' : variable_name,
                                 'from_value' : float(from_value),
                                 'to_value' : float(to_value),
                                 'step_value' : float(step_value),
                                 'for_execution_index' : self.__execution_index})
        self.set_variable(variable_name, from_value, False)

    def next_loop(self, variable_name):
        loop_info = None
        for i in range(len(self.__for_loops)-1, -1, -1):
            if self.__for_loops[i]['variable_name'] == variable_name:
                loop_info = self.__for_loops[i]
                break

        if loop_info is None:
            raise SyntaxError("Non existing FOR loop for '{0}'.".format(variable_name))

        loop_value = float(self.get_variable(variable_name))
        if loop_info['from_value'] <= loop_info['to_value']:
            loop_value = loop_value + abs(loop_info['step_value'])
            if loop_value < loop_info['to_value']:
                self.__execution_index = loop_info['for_execution_index']
        else:
            loop_value = loop_value - abs(loop_info['step_value'])
            if loop_value > loop_info['to_value']:
                self.__execution_index = loop_info['for_execution_index']

        if abs(loop_value) < 0.0001:
            loop_value = 0.0

        if float(int(loop_value)) == loop_value:
            self.set_variable(variable_name, int(loop_value), False)
        else:
            self.set_variable(variable_name, loop_value, False)

########################################################################################################################
########################################################################################################################
    def logger(self):
        return self.__logger

    def execute_command(self):
        if self.__execution_index < len(self.__execution_commands):
            try:
                self.__execution_commands[self.__execution_index].execute(self)
            except (RuntimeError, SyntaxError )as e:
                self.logger().error("Line {0} : '{1}' : {2}".format(
                    str(self.__execution_index + 1),
                    self.__execution_commands[self.__execution_index].get_name(),
                    str(e)))
                return False
            self.__execution_index += 1
            return True

        return False

    def store_execution_result(self, result):
        self.__execution_result = result

    def execution_result(self):
        return self.__execution_result

    def clean_execution_result(self):
        self.__execution_result = None

    def __execute_commands(self):
        while self.execute_command():
            pass

    def execute_commands(self, commands):
        self.__push_commands(commands)
        self.__execute_commands()
        self.__pop_commands()
########################################################################################################################
########################################################################################################################

    def evaluate_expression(self, expression):
        expression = expression.replace('datetime.datetime','datetime')
        expression = self._preprocess_variable(expression)

        eval_res = eval(expression, {"__builtins__":{}}, safe_eval_dict)
        expresion_eval = str(eval_res)

        if expresion_eval == 'True':
            expresion_eval = 1
        elif expresion_eval == 'False':
            expresion_eval = 0

        #self.logger().info("Evaluating expression '{0}' -> '{1}'".format(expression, expresion_eval))

        return expresion_eval

    def skip_if(self):
        nested_if_counter = 0
        #'is_if', 'is_endif'
        for i in range(self.__execution_index + 1, len(self.__execution_commands)):
            cmd_obj = self.__execution_commands[i]
            if hasattr(cmd_obj, 'is_if'):
                nested_if_counter += 1
            if nested_if_counter > 0:
                if hasattr(cmd_obj, 'is_endif'):
                    nested_if_counter -= 1
            else:
                if hasattr(cmd_obj,'is_endif') or hasattr(cmd_obj,'is_else'):
                    self.__execution_index = i
                    #self.logger().info("Skipping if")
                    return
########################################################################################################################
########################################################################################################################
    def set_return(self, value):
        self.set_variable('RETURN', value)

    def set_variable(self, name, value, print_info = True):
        if name.startswith(variable_mark):
            name = name[1:]
        self.__variables[name] = value
        if print_info:
            self.logger().info("{0} = {1}".format(str(name),str(value)))

    def get_variable(self, name):
        try:
            return self._get_variables()[name]
        except:
            raise RuntimeError("You must set variable '{0}' before it's usage !".format(name))

    def variable_exists(self, name):
        return name in self.__variables

    def load_variable_if_file(self, name, path_variable = 'TEST_CASES_PATH'):
        try:
            file_name = ''
            if os.path.isfile(name):
                file_name = name
            else:
                test_cases_path = os.path.normcase(context.get_variable(path_variable))
                relative_path = os.path.join(test_cases_path, file_name)
                relative_path2 = test_cases_path + file_name

                if os.path.isfile(relative_path):
                    file_name = relative_path
                if os.path.isfile(relative_path2):
                    file_name = relative_path2

            if file_name is not '':
                with open(file_name, 'r') as f:
                    self.logger().info("Loading variable  from '{0}'".format(file_name))
                    name = f.read()
        except:
            pass

        return self._preprocess_variable(name)

    def _get_variables(self):
        return self.__variables

    def _replace_case_insensitive(self, text, old, repl ):
        try:
            index_l = text.lower().index(old.lower())
        except:
            return text
        return self._replace_case_insensitive(text[:index_l] + repl + text[index_l + len(old):], old, repl)

    def _preprocess_variable(self, var):
        if variable_mark not in var:
            return var

        variables = self._get_variables()

        for v in sorted(variables, key=lambda v: len(str(variables[v])), reverse=False):
            var = self._replace_case_insensitive(var, variable_mark + v, str(variables[v]))

        #$result replacement
        var = self._replace_case_insensitive(var, variable_mark + 'result', str(self.__execution_result))

        #$datetime replacement
        var = self._replace_case_insensitive(var, variable_mark + 'datetime', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

        if variable_mark in var:
            self.logger().error("Non existing variable '{0}' !".format(var[var.index(variable_mark) + 1:]))

        return var

########################################################################################################################
########################################################################################################################
    def parse_arguments(self, arguments, delimeter = ','):
        args = []
        arg = ""
        type = None
        json_counter = 0

        for i in range(0,len(arguments)):
            letter = arguments[i]
            if type is None:
                if letter in [' ', delimeter]:
                    pass
                elif letter == '{':
                    type = 'json'
                    arg += letter
                    json_counter += 1
                elif letter == '"':
                    type = 'string'
                else:
                    type = 'keyword'
                    arg += letter
            #*********************************
            elif type == 'json':
                arg += letter
                if letter == '{':
                    json_counter += 1
                if letter == '}':
                    json_counter -= 1
                if json_counter == 0:
                    args.append(str(arg))
                    arg = ''
                    type = None
            # *********************************
            elif type == 'keyword':
                if letter in [' ', delimeter]:
                    args.append(str(arg))
                    arg = ''
                    type = None
                else:
                    arg += letter
            # *********************************
            elif type == 'string':
                if letter == '"':
                    args.append(str(arg))
                    arg = ''
                    type = None
                else:
                    arg += letter

        if type is not None:
            args.append(str(arg))

        #handling $variables
        for i in range(0,len(args)):
            args[i] = self._preprocess_variable(args[i])

        return args