from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from shutil import copyfile
from fisd_utils import *
import os

########################################################################################################################
# CmdCopy
########################################################################################################################
class CmdCopy(Cmd):
    command_name = 'COPY'

    @classmethod
    def create(cls, arguments):
        try:
            source, destination = arguments.split(',')
            source, i = parse_string(source)
            destination, i = parse_string(destination)
            return CmdCopy(source, destination)
        except:
            raise SyntaxError("Invalid {0} : '{1}'. Valid usage is : '{2}'"
                              .format(cls.command_name,
                                      arguments,
                                      CommandsFactory.get_property(cls.command_name, 'usage')))

    def execute(self, context):
        self.__source = context._preprocess_variable(self.__source)
        self.__destination = context._preprocess_variable(self.__destination)

        src = TestCasesPath.get_full_path(self.__source, context)
        dst = self.__destination
        if not os.path.isabs(self.__destination):
            dst = os.path.join(context.get_variable('TEST_CASES_PATH'), self.__destination, )

        try:
            copyfile(src, dst)
            context.logger().info("File succesfully copied from '{0}' to '{1}'".format(src, dst))
        except:
            raise RuntimeError("Unable to copy file from '{0}' to '{1}'".format(src, dst))

    def __init__(self, source, destination):
        super(Cmd, self).__init__()
        self.__source = source
        self.__destination = destination

########################################################################################################################
# CmdSetOPCClientPath
########################################################################################################################
class CmdSetOPCClientPath(Cmd):
    command_name = 'SET_OPC_CLIENT_PATH'

    @classmethod
    def create(cls, arguments):
        try:
            path, end_index = parse_string(arguments)
            return CmdSetOPCClientPath(path)
        except:
            raise SyntaxError("Invalid {0} : '{1}'. Valid usage is : '{2}'"
                              .format(cls.command_name,
                                      arguments,
                                      CommandsFactory.get_property(cls.command_name, 'usage')))

    def execute(self, context):
        if os.path.exists(self.__path):
            context.set_variable('OPC_CLIENT_PATH',self.__path)
        else:
            raise RuntimeError("Non existing path '{0}' !".format(self.__path))

    def __init__(self, path):
        super(Cmd, self).__init__()
        self.__path = path

########################################################################################################################
# CmdSetTestCasesPath
########################################################################################################################
class CmdSetTestCasesPath(Cmd):
    command_name = 'SET_TEST_CASES_PATH'

    @staticmethod
    def get_full_path(file_name, context, raise_exception = True):
        # absolute path
        if os.path.isfile(file_name):
            return file_name

        #relative to 'TEST_CASES_PATH' path
        test_cases_path = os.path.normcase(context.get_variable('TEST_CASES_PATH'))
        relative_path = os.path.join(test_cases_path, file_name)
        relative_path2 = test_cases_path + file_name

        if os.path.isfile(relative_path):
            return relative_path
        if os.path.isfile(relative_path2):
            return relative_path2

        if raise_exception:
            raise RuntimeError("Invalid relative or absolute path '{0}'".format(file_name))
        return file_name

    @staticmethod
    def get_relative_path(file_name, context):
        #relative to 'TEST_CASES_PATH' path
        test_cases_path = os.path.normcase(context.get_variable('TEST_CASES_PATH'))
        return os.path.join(test_cases_path, file_name)

    @classmethod
    def create(cls, arguments):
        try:
            path, end_index  = parse_string(arguments)
            return CmdSetTestCasesPath(path)
        except:
            raise SyntaxError("Invalid {0} : '{1}'. Valid usage is : '{2}'"
                              .format(cls.command_name,
                                      arguments,
                                      CommandsFactory.get_property(cls.command_name, 'usage')))

    def execute(self, context):
        if os.path.exists(self.__path):
            context.set_variable('TEST_CASES_PATH',self.__path)
        else:
            raise RuntimeError("Non existing path '{0}' !".format(self.__path))

    def __init__(self, path):
        super(Cmd, self).__init__()
        self.__path = path

########################################################################################################################
# CmdFileSearchLines
########################################################################################################################
class CmdFileSearchLines(Cmd):
    command_name = 'FILE_SEARCH_LINES'

    @classmethod
    def create(cls, arguments):
        return CmdFileSearchLines(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
            if len(args) < 2:
                raise_create_cmd_syntax_error(CmdFileSearchLines, self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdFileSearchLines, self.__arguments)

        context.logger().info("{0} '{1}', '{2}'".format(CmdFileSearchLines.command_name, args[0], args[1]))

        count = 0
        try:
            with open(args[0]) as f:
                for line in f.readlines():
                    if args[1] in line:
                        context.logger().info("[{0}]. '{1}'".format(count, line))
                        count+=1
        except Exception as e:
            context.logger().info(str(e))

        context.set_return(count)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments


########################################################################################################################
# CmdSetWorkingDir
########################################################################################################################
class CmdSetWorkingDir(Cmd):
    command_name = 'SET_WORKING_DIR'

    @classmethod
    def create(cls, arguments):
        return CmdSetWorkingDir(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
            if len(args) < 1:
                raise_create_cmd_syntax_error(CmdSetWorkingDir, self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdSetWorkingDir, self.__arguments)

        context.logger().info("{0} '{1}'".format(CmdSetWorkingDir.command_name, args[0]))

        os.chdir(args[0])

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# CmdSetFile
########################################################################################################################
class CmdSetFile(Cmd):
    command_name = 'SET_FILE'

    @classmethod
    def create(cls, arguments):
        return CmdSetFile(arguments)

    def execute(self, context):
        args = context.parse_arguments(self.__arguments)
        context.logger().info("SET_FILE " + " ".join(args))

        # SET_FILE INI ATTRIBUTE file_name, ini_attr_name, ini_attr_value
        if len(args) == 5 and args[0].upper() == 'INI' and args[1].upper() == 'ATTRIBUTE':
            value_string = args[4]
            try:
                float(value_string)
            except:
                try:
                    int(value_string)
                except:
                    value_string = '"' + value_string + '"'

            lines = []
            with open(args[2]) as f:
                lines = f.readlines()

            found = False

            for i in range(0,len(lines)):
                line = lines[i][:]
                comment_index = line.find("#")
                if comment_index >= 0:
                    line = line[:comment_index]

                split_marker_index = line.find("=")
                if split_marker_index >= 0:
                    line = line.replace("\n", "").replace("\r", "")
                    key = line[:split_marker_index - 1]
                    key = key.lstrip(" ").rstrip(" ")

                    if key == args[3]:
                        lines[i] = "{0} = {1}\n".format(args[3], value_string)
                        found = True
                        break

            if found == False:
                lines.append("{0} = {1}\n".format(args[3], value_string))

            with open(args[2], "w") as f:
                f.writelines(lines)
                return

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments
########################################################################################################################
# Commands registration
########################################################################################################################
CommandsFactory.register_command(CmdSetOPCClientPath.command_name,
                                 CmdSetOPCClientPath.create,
                                 usage = 'SET_OPC_CLIENT_PATH "d:/inspiring\opc_client"',
                                 description = '')

CommandsFactory.register_command(CmdSetTestCasesPath.command_name,
                                 CmdSetTestCasesPath.create,
                                 usage='SET_TEST_CASES_PATH "d:/inspiring\TEST_CASES"',
                                 description='')

CommandsFactory.register_command(CmdCopy.command_name,
                                 CmdCopy.create,
                                 usage='COPY "source","destination"',
                                 description='')

CommandsFactory.register_command(CmdFileSearchLines.command_name,
                                 CmdFileSearchLines.create,
                                 usage='FILE_SEARCH_LINES file_path, string',
                                 description='')

CommandsFactory.register_command(CmdSetWorkingDir.command_name,
                                 CmdSetWorkingDir.create,
                                 usage='SET_WORKING_DIR dir',
                                 description='')

CommandsFactory.register_command(CmdSetFile.command_name,
                                 CmdSetFile.create,
                                 usage='SET_FILE INI ATTRIBUTE file_name, ini_atribute_name, ini_attribute_value',
                                 description='')
