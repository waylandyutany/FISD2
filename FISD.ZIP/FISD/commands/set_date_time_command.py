from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from datetime import datetime, timedelta
from fisd_utils import *
import os

########################################################################################################################
# Command SET_TIME
########################################################################################################################
class CmdSetTime(Cmd):
    command_name = 'SET_TIME'
    @staticmethod
    def create(arguments):
        arguments = arguments.replace(' ','')
        dt = None
        try:
            dt = datetime.strptime(arguments,"%H:%M:%S")
        except:
            raise SyntaxError("Invalid SET_TIME time : '{0}'. Valid usage is : '{1}'"
                              .format(arguments, CommandsFactory.get_property(CmdSetTime.command_name, 'usage')))

        return CmdSetTime(dt)

    def execute(self, context):
        time_cmd = "time %i:%i:%i" % (self.__time.hour,
                                      self.__time.minute,
                                      self.__time.second)


        context.logger().info("Setting time to {0}".format(self.__time.strftime("%H:%M:%S")))
        run_cmd_as_admin(time_cmd)

    def __init__(self, time):
        super(Cmd, self).__init__()
        self.__time = time

########################################################################################################################
# Command SET_DATE
########################################################################################################################
class CmdSetDate(Cmd):
    command_name = 'SET_DATE'

    @staticmethod
    def create(arguments):
        arguments = arguments.replace(' ','')
        dt = None
        try:
            dt = datetime.strptime(arguments,"%Y/%m/%d")
        except:
            try:
                dt = datetime.strptime(arguments, "%Y-%m-%d")
            except:
                raise SyntaxError("Invalid SET_DATE time : '{0}'. Valid usage is : '{1}'"
                                  .format(arguments, CommandsFactory.get_property(CmdSetDate.command_name,'usage')))

        return CmdSetDate(dt)

    def execute(self, context):
        date_cmd = "date %i-%i-%i" % (self.__date.month,
                                      self.__date.day,
                                      self.__date.year)
        context.logger().info("Setting date to {0}".format(self.__date.strftime("%Y-%m-%d")))
        run_cmd_as_admin(date_cmd)

    def __init__(self, date):
        super(Cmd, self).__init__()
        self.__date = date

CommandsFactory.register_command(CmdSetTime.command_name, CmdSetTime.create,
                                 usage = 'SET_TIME 16:00:00')
CommandsFactory.register_command(CmdSetDate.command_name, CmdSetDate.create,
                                 usage = 'SET_DATE 2016/05/29; SET_DATE 2016-05-29')
