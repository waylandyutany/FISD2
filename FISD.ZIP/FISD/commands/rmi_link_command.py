from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from file_commands import CmdSetTestCasesPath as TestCasesPath
import os, time
from py_iim_lib.rmi_link_command import run_rmilink_connection_simulation, run_rmilink_connection_command
from py_iim_lib.rmi_link_command import post_rmilink_command, get_rmilink_command
from py_iim_lib.rmi_link_web_client import keyWSEnabled, load_web_client_info

#RMI_LINK_GET_COMMAND Version,...

web_client_info_single_instance = None

def load_web_client_info_single_instance(context):
    global web_client_info_single_instance
    if web_client_info_single_instance is not None:
        return web_client_info_single_instance

    rmi_link_ini_path = context.get_variable('RMI_LINK_INI_PATH')
    web_client_info_single_instance = load_web_client_info(rmi_link_ini_path)

    if (web_client_info_single_instance == None) or (str(web_client_info_single_instance[keyWSEnabled]).lower() != 'true'):
        context.logger().info("RMILink Web Service is not enabled ! Check '{0}' !".format(rmi_link_ini_path))

    return web_client_info_single_instance

def check_adapter_and_connection(context, web_client_info, adapter_name, topic_name):
#    adapters = get_rmilink_command(web_client_info, "InstalledAdapters")
    connections = get_rmilink_command(web_client_info, "OpenConnections/{0}".format(adapter_name)).content
    if '"' + topic_name + '"' not in str(connections):
        context.logger().error("Unable to find '{0}' adapter with '{1}' connection !".format(adapter_name, topic_name))
        return False
    return True

########################################################################################################################
# CmdStartFlippingSim
########################################################################################################################
class CmdStartFlippingSim(Cmd):
    command_name = 'START_FLIPPING_SIM'
    @classmethod
    def create(cls, arguments):
        try:
            topic_name, sim_template_file = arguments.split(",")
            topic_name, i = parse_string(topic_name)
            sim_template_file, i = parse_string(sim_template_file)
            return CmdStartFlippingSim(topic_name, sim_template_file)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        web_client_info = load_web_client_info_single_instance(context)
        if web_client_info and str(web_client_info[keyWSEnabled]).lower() == 'true':
            if not check_adapter_and_connection(context, web_client_info, "TT4Simulator", self.__topic_name):
                return

            context.logger().info("Running RMILink Web Service on : '{0}'".format(str(web_client_info)))
            context.logger().info("Running RMILink Web Service '{cmd}' command...".format(cmd=CmdStartFlippingSim.command_name))

            result = run_rmilink_connection_simulation(web_client_info,
                                                        self.__topic_name,
                                                        'StartFLPSimulation',
                                                        TestCasesPath.get_full_path(self.__sim_template_file,context))
            context.logger().info(str(result))
            context.logger().info(str(result.content))
            return

    def __init__(self, topic_name, sim_template_file):
        super(Cmd, self).__init__()
        self.__topic_name = topic_name
        self.__sim_template_file = sim_template_file


########################################################################################################################
# CmdStartToggleSim
########################################################################################################################
class CmdStartToggleSim(Cmd):
    command_name = 'START_TOGGLE_SIM'
    @classmethod
    def create(cls, arguments):
        try:
            topic_name, sim_template_file = arguments.split(",")
            topic_name, i = parse_string(topic_name)
            sim_template_file, i = parse_string(sim_template_file)
            return CmdStartToggleSim(topic_name, sim_template_file)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        web_client_info = load_web_client_info_single_instance(context)
        if web_client_info and str(web_client_info[keyWSEnabled]).lower() == 'true':
            if not check_adapter_and_connection(context, web_client_info, "TT4Simulator", self.__topic_name):
                return

            context.logger().info("Running RMILink Web Service on : '{0}'".format(str(web_client_info)))
            context.logger().info("Running RMILink Web Service '{cmd}' command...".format(cmd=CmdStartToggleSim.command_name))

            result = run_rmilink_connection_simulation(web_client_info,
                                                        self.__topic_name,
                                                        'StartTBLSimulation',
                                                        TestCasesPath.get_full_path(self.__sim_template_file,context))
            context.logger().info(str(result))
            context.logger().info(str(result.content))
            return

    def __init__(self, topic_name, sim_template_file):
        super(Cmd, self).__init__()
        self.__topic_name = topic_name
        self.__sim_template_file = sim_template_file

########################################################################################################################
# CmdRunRmiLinkCommand
########################################################################################################################
class CmdRunRmiLinkCommand(Cmd):
    command_name = 'RUN_RMILINK_CMD'
    @classmethod
    def create(cls, arguments):
        try:
            args = arguments.split(",")
            topic_name, i = parse_string(args[0])
            command, i = parse_string(args[1])
            params = []
            for i in range(2,len(args)):
                param, pos = parse_string(args[i])
                params.append(param)

            return CmdRunRmiLinkCommand(topic_name, command, params)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        web_client_info = load_web_client_info_single_instance(context)
        if web_client_info and str(web_client_info[keyWSEnabled]).lower() == 'true':
            if not check_adapter_and_connection(context, web_client_info, "TestAdapter", self.__topic_name):
                return

            context.logger().info("Running RMILink Web Service on : '{0}'".format(str(web_client_info)))

            context.logger().info("Running Test adapter command...")
            context.logger().info("    Topic = '{topic}', Command = '{command}', Params = '{params}'".format(
                    topic=self.__topic_name,
                    command=self.__command,
                    params=self.__params))

            result = run_rmilink_connection_command(web_client_info, self.__topic_name, self.__command, self.__params)
            context.logger().info(str(result))
            context.logger().info(str(result.content))
            return

    def __init__(self, topic_name, command, params):
        super(Cmd, self).__init__()
        self.__topic_name = topic_name
        self.__command = command
        self.__params = params

########################################################################################################################
# CmdPostRmiLinkCommand
########################################################################################################################
class CmdPostRmiLinkCommand(Cmd):
    command_name = 'POST_RMILINK_CMD'
    @classmethod
    def create(cls, arguments):
        return CmdPostRmiLinkCommand(arguments)

    def execute(self, context):
        args = context.parse_arguments(self.__arguments)
        try:
            json_data = context.load_variable_if_file(args[0])
        except:
            raise_create_cmd_syntax_error(CmdPostRmiLinkCommand, self.__arguments)

        web_client_info = load_web_client_info_single_instance(context)
        if web_client_info and str(web_client_info[keyWSEnabled]).lower() == 'true':
            context.logger().info("Running RMILink Web Service on : '{0}'".format(str(web_client_info)))
            context.logger().info("POST ing RMILink Web Service '{0}'...".format(str(json_data)))

            result = post_rmilink_command(web_client_info, json_data)

            context.logger().info(str(result))
            context.set_return(str(result.content))

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# CmdGetRmiLinkCommand
########################################################################################################################
class CmdGetRmiLinkCommand(Cmd):
    command_name = 'GET_RMILINK_CMD'
    @classmethod
    def create(cls, arguments):
        return CmdGetRmiLinkCommand(arguments)

    def execute(self, context):
        args = context.parse_arguments(self.__arguments)
        try:
            get_path = args[0]
        except:
            raise_create_cmd_syntax_error(CmdGetRmiLinkCommand, self.__arguments)

        web_client_info = load_web_client_info_single_instance(context)
        if web_client_info and str(web_client_info[keyWSEnabled]).lower() == 'true':
            context.logger().info("Running RMILink Web Service on : '{0}'".format(str(web_client_info)))
            context.logger().info("GET ing RMILink Web Service '/{0}'...".format(str(get_path)))

            result = get_rmilink_command(web_client_info, get_path)

            context.logger().info(str(result))
            context.set_return(str(result.content))

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# Commands registration
CommandsFactory.register_command(CmdStartFlippingSim.command_name,
                                 CmdStartFlippingSim.create,
                                 usage = 'START_FLIPPING_SIM topic_name, flipping_sim_template.xlsx',
                                 description = 'Start flipping simulation')

CommandsFactory.register_command(CmdStartToggleSim.command_name,
                                 CmdStartToggleSim.create,
                                 usage='START_TOGGLE_SIM topic_name, toggle_sim_template.xlsx',
                                 description='Start toggle simulation')

CommandsFactory.register_command(CmdRunRmiLinkCommand.command_name,
                                 CmdRunRmiLinkCommand.create,
                                 usage='RUN_RMILINK_CMD topic_name, command, param0, param1, param2',
                                 description='Run Rmi Link command on test adapter')

CommandsFactory.register_command(CmdPostRmiLinkCommand.command_name,
                                 CmdPostRmiLinkCommand.create,
                                 usage='POST_RMILINK_CMD json; POST_RMILINK_CMD json_file',
                                 description='Post json to rmi link web service.')

CommandsFactory.register_command(CmdGetRmiLinkCommand.command_name,
                                 CmdGetRmiLinkCommand.create,
                                 usage='GET_RMILINK_CMD get_parh;',
                                 description='Get response from rmi link web service.')
