from socket import socket, AF_INET, SOCK_STREAM
from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from fisd_utils import *
from file_commands import CmdSetTestCasesPath as TestCasesPath
import os, time
from subprocess import Popen

TOKEN_START = '<start>'
TOKEN_STOP = '<end>'
# Protocol commands (NOTE: keep all commands uppercase!)
CMD_STATUS = 'STATUS'

########################################################################################################################
# CmdSendOpcCommand
########################################################################################################################
class CmdSendOpcCommand(Cmd):
    command_name = 'SEND_OPC_COMMAND'

    @classmethod
    def create(cls, arguments):
        return CmdSendOpcCommand(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
            if len(args) != 3:
                raise_create_cmd_syntax_error(CmdSendOpcCommand, self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdSendOpcCommand, self.__arguments)

        ip, port, command = args
        context.logger().info("{0} '{1}', {2}, {3}".format(CmdSendOpcCommand.command_name, ip, port, command))

        while True:
            try:
                s = socket(AF_INET, SOCK_STREAM)
                s.connect((ip, int(port)))
                command = ''.join(
                    (
                    TOKEN_START, repr((command,)), TOKEN_STOP))
                s.sendall(command)
                time.sleep(0.5)
                response = s.recv(1024)
                s.close()
                context.logger().info(response)
                break
            except Exception as e:
                context.logger().info(e)
            time.sleep(0.5)

        #        context.set_return(count)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# CmdStartOPCClient
########################################################################################################################
class CmdStartOPCClient(Cmd):
    command_name = 'START_OPC_CLIENT'
    key_wait_running = 'WAIT_RUNNING'
    opc_client_processes = []

    @classmethod
    def create(cls, arguments):
        try:
            if str(arguments).upper().startswith(cls.key_wait_running):
                arguments = arguments[len(cls.key_wait_running):].lstrip()
                if len(arguments) > 0:
                    opc_client_port_string = arguments.split(' ')[0]
                    arguments = arguments[len(opc_client_port_string):].lstrip()
                return CmdStartOPCClient(arguments, int(opc_client_port_string))
            return CmdStartOPCClient(arguments, None)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        opc_client_path = os.path.join(context.get_variable('OPC_CLIENT_PATH'), context.get_variable('OPC_CLIENT_NAME'))
        CmdStartOPCClient.opc_client_processes.append(Popen(opc_client_path + " " + self.__arguments, shell = True))
        context.logger().info("OPCClient started. Arguments : " + self.__arguments)
        context.logger().info("OPCClient started. file '{0}'".format(opc_client_path))
        if self.__opc_client_port is not None:
            while True:
                try:
                    s = socket(AF_INET, SOCK_STREAM)
                    s.connect(('127.0.0.1', self.__opc_client_port))
                    command = ''.join(
                        (TOKEN_START, repr((CMD_STATUS,)), TOKEN_STOP))
                    s.sendall(command)
                    time.sleep(0.5)
                    response = s.recv(1024)
                    s.close()
                    context.logger().info(
                        "Waiting for full OPCClient initialization on {0}... '{1}'".format(str(self.__opc_client_port), response))
                    if '[2]' in response:
                        context.logger().info(
                            "OPCClient initialized on {0} [{1}]".format(str(self.__opc_client_port), response))
                        break
                except Exception as e:
                    pass
                time.sleep(0.5)

    def __init__(self, arguments, opc_client_port):
        super(Cmd, self).__init__()
        self.__arguments = arguments
        self.__opc_client_port = opc_client_port


########################################################################################################################
# CmdStopOPCClient
########################################################################################################################
class CmdStopOPCClient(Cmd):
    command_name = 'STOP_OPC_CLIENT'

    @classmethod
    def create(cls, arguments):
        try:
            return CmdStopOPCClient()
        except:
            raise_create_cmd_syntax_error(cls)

    def execute(self, context):
        for opc_client_process in CmdStartOPCClient.opc_client_processes:
            subprocess.Popen("TASKKILL /F /PID {pid} /T".format(pid=opc_client_process.pid),
                             stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT).wait()
            opc_client_process.wait()

        context.logger().info("{0} OPC Client stopped.".format(len(CmdStartOPCClient.opc_client_processes)))
        CmdStartOPCClient.opc_client_processes = []

    def __init__(self):
        super(Cmd, self).__init__()

########################################################################################################################
# CmdSetOPCClientDebug
########################################################################################################################
class CmdSetOPCClientDebug(Cmd):
    command_name = 'SET_OPC_CLIENT_DEBUG'

    @classmethod
    def create(cls, arguments):
        try:
            sep_index = arguments.find("=")
            variable_name, i = parse_string(arguments[:sep_index])
            variable_value = arguments[sep_index + 1:]
            return CmdSetOPCClientDebug(variable_name, variable_value.lstrip().rstrip())
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        debug_lines = []
        with open(os.path.join(context.get_variable('OPC_CLIENT_PATH'),"Debug.ini"),"r") as f:
            for line in f.readlines():
                debug_lines.append(line)

        for i in range(0,len(debug_lines)):
            if self.__variable_name in debug_lines[i]:
                debug_lines[i] = "{0} = {1}\r\n".format(self.__variable_name, self.__variable_value)

        with open(os.path.join(context.get_variable('OPC_CLIENT_PATH'), "Debug.ini"), "w") as f:
            f.writelines(debug_lines)

        context.logger().info("OPCCLient.Debug.ini {0} = {1}".format(self.__variable_name, self.__variable_value))

    def __init__(self, variable_name, variable_value):
        super(Cmd, self).__init__()
        self.__variable_name = variable_name
        self.__variable_value = variable_value

########################################################################################################################
# CmdCopyCfg
########################################################################################################################
class CmdCopyCfg(Cmd):
    command_name = 'COPY_CFG'

    @classmethod
    def create(cls, arguments):
        try:
            src_file, config_file = arguments.split(',')
            src_file, i = parse_string(src_file)
            config_file, i = parse_string(config_file )
            return CmdCopyCfg(src_file, config_file)
        except:
            raise SyntaxError("Invalid {0} : '{1}'. Valid usage is : '{2}'"
                      .format(cls.command_name,
                              arguments,
                              CommandsFactory.get_property(cls.command_name, 'usage')))

    def execute(self, context):
        dst = os.path.join(context.get_variable('OPC_CLIENT_PATH'),
                           "conf",
                           self.__config_file + ".cfg")
        src = TestCasesPath.get_full_path(self.__src_file, context)
        try:
            copyfile(src, dst)
            context.logger().info("File succesfully copied from '{0}' to '{1}'".format(src, dst))
        except:
            raise RuntimeError("Unable to copy file from '{0}' to '{1}'".format(src, dst))

    def __init__(self, src_file, config_file):
        super(Cmd, self).__init__()
        self.__src_file = src_file
        self.__config_file = config_file

########################################################################################################################
# Commands registration
########################################################################################################################
CommandsFactory.register_command(CmdStartOPCClient.command_name,
                                 CmdStartOPCClient.create,
                                 usage = 'START_OPC_CLIENT;START_OPC_CLIENT WAIT_RUNNING 1234;',
                                 description = 'Start OPCCLient application')

CommandsFactory.register_command(CmdStopOPCClient.command_name,
                                 CmdStopOPCClient.create,
                                 usage='STOP_OPC_CLIENT',
                                 description='Stop OPCCLient application')

CommandsFactory.register_command(CmdSetOPCClientDebug.command_name,
                                 CmdSetOPCClientDebug.create,
                                 usage='SET_OPC_CLIENT_DEBUG DebugSessionDurationSecs = 86400',
                                 description='Set OPCClient Debug.ini attribute')

CommandsFactory.register_command(CmdCopyCfg.command_name,
                                 CmdCopyCfg.create,
                                 usage='COPY_CFG "d:/inspiring/gmcs10.cfg", GMCS10',
                                 description='')

CommandsFactory.register_command(CmdSendOpcCommand.command_name,
                                 CmdSendOpcCommand.create,
                                 usage=CmdSendOpcCommand.command_name + ' 127.0.0.1, 10024, "STATUS" ',
                                 description='')

