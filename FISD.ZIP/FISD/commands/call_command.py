from file_commands import CmdSetTestCasesPath as TestCasesPath
from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from fisd_utils import *

#not parse already parsed files, implemented in parse_and_create_command
class CmdExecute(Cmd):
    command_name = 'EXECUTE'

    @classmethod
    def create(cls, arguments):
        try:
            file_name, i = parse_string(arguments)
            try:
                file_name = os.path.join(CommandsFactory.default_commands_directory, file_name)
                if not os.path.exists(file_name):
                    raise SyntaxError("Invalid file '{0}' !".format(file_name))
            except:
                raise SyntaxError("Invalid file '{0}' !".format(file_name))

            commands, number_errors = CommandsFactory.parse_commands(file_name)
            if number_errors > 0:
                raise SyntaxError("Please fix all {0} errors in {1} !".format(number_errors, file_name))

            return CmdExecute(file_name, commands)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        context.logger().info(">>> Executing '{0}' commands...".format(self.__commands_name))
        context.execute_commands(self.__commands)
        context.logger().info("<<< Commands '{0}' executed.".format(self.__commands_name))

    def __init__(self, commands_name, commands):
        super(Cmd, self).__init__()
        self.__commands = commands
        self.__commands_name = commands_name

CommandsFactory.register_command(CmdExecute.command_name,CmdExecute.create,usage = 'EXECUTE fisd_file.fisd')
