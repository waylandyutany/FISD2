from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from fisd_utils import *
import imp
import opcclientdll

########################################################################################################################
# CmdSatTag
########################################################################################################################
class CmdSetTag(Cmd):
    drv = opcclientdll.opcclient()
    command_name = 'SET_TAG'
    pc_server_opc = ''
    opc_server_name = 'RSLinx OPC Server'
    hconnect = -1
    grp_handle = -1
    added_tags = []

    @classmethod
    def create(cls, arguments):
        try:
            sep_index = arguments.find("=")
            tag_address, i = parse_string(arguments[:sep_index])
            tag_value = arguments[sep_index + 1:]
            return CmdSetTag(tag_address, tag_value)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        if CmdSetTag.hconnect < 0:
            CmdSetTag.hconnect = CmdSetTag.drv.ConnectOPC(CmdSetTag.pc_server_opc,
                                                          CmdSetTag.opc_server_name,
                                                          0)
            CmdSetTag.drv.SetParameters(0, 10)
            time.sleep(0.5)
        if CmdSetTag.hconnect < 0:
            context.logger().error("Unable to connect to OPC Server('{0}', '{1}')".format(CmdSetTag.pc_server_opc,
                                                                                     CmdSetTag.opc_server_name))

        if CmdSetTag.grp_handle < 0:
            CmdSetTag.grp_handle = CmdSetTag.drv.AddOPCGroup(CmdSetTag.hconnect, "test_group", 0.1, 0)
            time.sleep(0.5)
        if CmdSetTag.grp_handle < 0:
            context.logger().error("Unable to add OPC group 'test_group'")

        try:
            self.__tag_index = CmdSetTag.added_tags.index(self.__tag_address)
        except:
            CmdSetTag.added_tags.append(self.__tag_address)
            self.__tag_index = CmdSetTag.added_tags.index(self.__tag_address)
            CmdSetTag.drv.AddOPCItem(CmdSetTag.hconnect, CmdSetTag.grp_handle, self.__tag_index, self.__tag_address)
            context.logger().info("Added OPC Item '{0}' on index {1}".format(self.__tag_address, str(self.__tag_index)))
            time.sleep(0.5)

        if self.__tag_index >= 0:
            CmdSetTag.drv.WriteTagValue(CmdSetTag.hconnect,
                                        CmdSetTag.grp_handle,
                                        self.__tag_index,
                                        str(self.__tag_value))

            context.logger().info("SET_TAG {0} = {1}".format(self.__tag_address,
                                                             self.__tag_value))

    def __init__(self, tag_address, tag_value):
        super(Cmd, self).__init__()
        self.__tag_address = tag_address
        self.__tag_value = tag_value
        self.__tag_index = -1

########################################################################################################################
# Commands registration
CommandsFactory.register_command(CmdSetTag.command_name,
                                 CmdSetTag.create,
                                 usage = 'Dummy usage',
                                 description = 'Dummy description')
