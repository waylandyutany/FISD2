from fisd_commands_factory import CommandsFactory
from file_commands import CmdSetTestCasesPath as TestCasesPath
from fisd_command import Cmd
from fisd_utils import *
from subprocess import Popen
import os
from fisd_context import variable_mark
import glob

########################################################################################################################
########################################################################################################################
from win32api import GetFileVersionInfo, LOWORD, HIWORD

def get_version_number (filename):
    try:
        info = GetFileVersionInfo (filename, "\\")
        ms = info['FileVersionMS']
        ls = info['FileVersionLS']
        return HIWORD (ms), LOWORD (ms), HIWORD (ls), LOWORD (ls)
    except:
        return 0,0,0,0

########################################################################################################################
# Command GET
########################################################################################################################
searched_files = []
class CmdGet(Cmd):
    command_name = 'GET'

    @classmethod
    def create(cls, arguments):
        return CmdGet(arguments)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

    def execute(self, context):
        global searched_files
        args = context.parse_arguments(self.__arguments)
        context.logger().info("GET " + " ".join(args))

        # GET FILE SIZE 'file_name'
        if len(args) == 3 and args[0].upper() == 'FILE' and args[1].upper() == 'SIZE':
            with open(args[2], 'rb') as f:
                f.seek(0, 2)
                size = f.tell()
                context.set_return(size)
        # GET FILE VERSION 'file_name'
        elif len(args) == 3 and args[0].upper() == 'FILE' and args[1].upper() == 'VERSION':
            v = get_version_number(args[2])
            context.set_return("{0}.{1}.{2}.{3}".format(v[0],v[1],v[2],v[3]))
        # GET FILE LINES 'file_name'
        elif len(args) == 3 and args[0].upper() == 'FILE' and args[1].upper() == 'LINES':
            with open(args[2], 'rb') as f:
                context.set_return(len(f.readlines()))
        # GET FILE LINE 'file_name', 10
        elif len(args) == 4 and args[0].upper() == 'FILE' and args[1].upper() == 'LINE':
            with open(args[2], 'rb') as f:
                lines = f.readlines()
                index = int(args[3])
                if index < len(lines):
                    context.set_return(lines[index])
                else:
                    raise SyntaxError("Line index[{0}] out of range[{1}]!".format(str(index), str(int(len(lines)))))
        # GET SEARCH FILES 'file_name'
        elif len(args) == 3 and args[0].upper() == 'SEARCH' and args[1].upper() == 'FILES':
            searched_files = glob.glob(args[2])
            try:
                context.set_return(len(searched_files))
            except:
                context.set_return(0)
        # GET SEARCH FILE index
        elif len(args) == 3 and args[0].upper() == 'SEARCH' and args[1].upper() == 'FILE':
            context.set_return(searched_files[int(args[2])])
        else:
            raise SyntaxError("Unknown GET command!")

########################################################################################################################
# Command PAUSE
########################################################################################################################
class CmdPause(Cmd):
    command_name = 'Pause'

    @classmethod
    def create(cls, arguments):
        return CmdPause()

    def execute(self, context):
        context.logger().info("****************************")
        context.logger().info("Press 'Enter' to continue...")
        os.system('pause>nul')

########################################################################################################################
# Command IF, ELIF,ELSE, ENDIF
########################################################################################################################
class CmdIf(Cmd):
    command_name = 'IF'

    @classmethod
    def create(cls, arguments):
        return CmdIf(arguments)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments
        self.is_if = True

    def execute(self, context):
        arguments_with_then = str(self.__arguments).rstrip()
        if not arguments_with_then.lower().endswith("then"):
            raise_create_cmd_syntax_error(CmdIf, self.__arguments)

        expression = arguments_with_then[:-4]

        if context.evaluate_expression(expression) == 0:
            context.skip_if()

########################################################################################################################
class CmdElse(Cmd):
    command_name = 'ELSE'

    @classmethod
    def create(cls, arguments):
        return CmdElse(arguments)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments
        self.is_else = True

    def execute(self, context):
        #context.logger().info("ELSE")
        context.skip_if()
########################################################################################################################
class CmdEndIf(Cmd):
    command_name = 'ENDIF'

    @classmethod
    def create(cls, arguments):
        return CmdEndIf(arguments)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments
        self.is_endif = True

    def execute(self, context):
        #context.logger().info("ENDIF")
        pass

########################################################################################################################
# Command For, Next
########################################################################################################################
class CmdFor(Cmd):
    command_name = 'FOR'

    @classmethod
    def create(cls, arguments):
        return CmdFor(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
            if len(args) < 5:
                raise_create_cmd_syntax_error(CmdFor, self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdFor, self.__arguments)

        variable_name = args[0]

        if str(args[1]).lower() != 'from':
            raise SyntaxError("2nd argument must be 'FROM' and not '{0}' !".format(args[1]))
        from_value = args[2]

        if str(args[3]).lower() != 'to':
            raise SyntaxError("4th argument must be 'TO' and not '{0}' !".format(args[3]))
        to_value = args[4]

        step_value = 1
        if len(args) > 5:
            if str(args[5]).lower() != 'step':
                raise SyntaxError("6th argument must be 'STEP' and not '{0}' !".format(args[5]))
            step_value = args[6]

        context.logger().info("FOR '{variable_name}' FROM '{from_value}' TO '{to_value}' STEP '{step_value}'".format(
            variable_name = variable_name, from_value = from_value, to_value = to_value, step_value = step_value
        ))

        context.for_loop(variable_name,
                         from_value,
                         to_value,
                         step_value)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

class CmdNext(Cmd):
    command_name = 'NEXT'

    @classmethod
    def create(cls, arguments):
        return CmdNext(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
            if len(args) != 1:
                raise_create_cmd_syntax_error(CmdNext, self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdNext, self.__arguments)

        variable_name = args[0]
        #context.logger().info("NEXT '{variable_name}'".format(variable_name = variable_name))
        context.next_loop(variable_name)

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments


########################################################################################################################
# Command Print
########################################################################################################################
class CmdPrint(Cmd):
    command_name = 'PRINT'

    @classmethod
    def create(cls, arguments):
        return CmdPrint(arguments)

    def execute(self, context):
        try:
            args = context.parse_arguments(self.__arguments)
        except:
            raise_create_cmd_syntax_error(CmdPrint, self.__arguments)

        context.logger().info('PRINT ' + ", ".join(args))

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# Command Print2File
########################################################################################################################
class CmdPrint2File(Cmd):
    command_name = 'PRINT2FILE'

    @classmethod
    def create(cls, arguments):
        return CmdPrint2File(arguments)

    def execute(self, context):
        filename = ''
        try:
            args = context.parse_arguments(self.__arguments)
            if(len(args) < 2):
                raise
            filename = TestCasesPath.get_relative_path(args[0], context)
        except:
            raise_create_cmd_syntax_error(CmdPrint2File, self.__arguments)

        with open(filename, 'a') as f:
            for line in args[1:]:
                f.write(line + "\r\n")

        context.logger().info('PRINT2FILE ' + ", ".join(args))

    def __init__(self, arguments):
        super(Cmd, self).__init__()
        self.__arguments = arguments

########################################################################################################################
# Command Set
########################################################################################################################
class CmdSet(Cmd):
    command_name = 'SET'
    @classmethod
    def create(cls, arguments):
        try:
            sep_index = arguments.find("=")
            variable_name, i = parse_string(arguments[:sep_index])
            variable_value, i = parse_string(arguments[sep_index + 1 : ])
            if str(variable_name).startswith(variable_mark):
                variable_name = variable_name[1:]
            return CmdSet(variable_name, variable_value)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            context.set_variable(self.__variable_name, context.evaluate_expression(self.__variable_value))
        except:
            context.set_variable(self.__variable_name, context._preprocess_variable(self.__variable_value))

    def __init__(self, variable_name, variable_value):
        super(Cmd, self).__init__()
        self.__variable_name  = variable_name
        self.__variable_value = variable_value

########################################################################################################################
# Command Run
########################################################################################################################
class CmdRun(Cmd):
    command_name = 'RUN'
    @classmethod
    def create(cls, arguments):
        try:
            hide = False
            timeout = 0
            args = arguments.split(",")

            #optional HIDE parse
            if args[0].lstrip().rstrip().upper() == 'HIDE':
                hide = True
                args.pop(0)

            #cmd line parse
            cmd_line, i = parse_string(args[0])
            args.pop(0)

            #optional timeout parse
            if len(args) > 0:
                timeout, i = parse_string(args[0])

            return CmdRun(hide, cmd_line, int(timeout))
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        self.__run_command = context._preprocess_variable(self.__run_command)

        if self.__time_out > 0:
            context.logger().info("RUN {0} command executing with timeout {1}, Hide {2} ...".format(self.__run_command,
                                                                                         self.__time_out, self.__hide))
        else:
            context.logger().info("RUN {0} command executing without timeout, Hide {1} ...".format(self.__run_command,
                                                                                                    self.__hide))
        cmd_file_name = TestCasesPath.get_full_path(self.__run_command, context, False)
        run_cmd_as_admin(cmd_file_name, self.__time_out, self.__hide)

    def __init__(self, hide, run_command, time_out):
        super(Cmd, self).__init__()
        self.__hide = hide
        self.__run_command = run_command
        self.__time_out = time_out

########################################################################################################################
# Command Start/Stop service
########################################################################################################################
class CmdStartService(Cmd):
    command_name = 'START_SERVICE'
    @classmethod
    def create(cls, arguments):
        try:
            return CmdStartService(arguments.lstrip().rstrip())
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        run_cmd_as_admin("net start {0}".format(self.__service_name))

    def __init__(self, service_name):
        super(Cmd, self).__init__()
        self.__service_name = service_name

class CmdStopService(Cmd):
    command_name = 'STOP_SERVICE'
    @classmethod
    def create(cls, arguments):
        try:
            return CmdStopService(arguments.lstrip().rstrip())
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        run_cmd_as_admin("net stop {0}".format(self.__service_name))
        try:
            subprocess.Popen("TASKKILL /F /IM {service_name} /T".format(service_name=self.__service_name),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except:
            pass

    def __init__(self, service_name):
        super(Cmd, self).__init__()
        self.__service_name = service_name

########################################################################################################################
# Command STORE_RESULT
########################################################################################################################

class CmdStoreResult(Cmd):
    command_name = 'STORE_RESULT'
    @classmethod
    def create(cls, arguments):
        try:
            file_name, i = parse_string(arguments.lstrip().rstrip())
            return CmdStoreResult(file_name)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            result_file_name = os.path.join(context.get_variable('TEST_CASES_PATH'), self.__file_name)
            context.logger().info("Storing result into '{0}'...".format(result_file_name))
            with open(result_file_name, 'w') as f:
                if context.execution_result() is None:
                    context.logger().info("No result to be store into '{0}' !".format(result_file_name))
                    f.write(str("No result to be store here !"))
                else:
                    try:
                        if result_file_name.lower().endswith('.csv'):
                            result = context.execution_result()
                            for line in result:
                                line_values = []
                                for value in line:
                                    line_values.append(str(value))
                                f.write("; ".join(line_values))
                                f.write('\n')
                        else:
                            f.write(str(context.execution_result()))
                    except:
                        f.write(str(context.execution_result()))
        except:
            raise RuntimeError("Unable to store result into '{0}'. {2} !".format(result_file_name, str(e)))

    def __init__(self, file_name):
        super(Cmd, self).__init__()
        self.__file_name = file_name

# Commands registration
CommandsFactory.register_command(CmdGet.command_name, CmdGet.create, usage = 'GET FILE SIZE')
CommandsFactory.register_command(CmdPause.command_name, CmdPause.create, usage = 'PAUSE')
CommandsFactory.register_command(CmdIf.command_name, CmdIf.create, usage = 'IF {expresion} THEN; IF I==0 THEN')
CommandsFactory.register_command(CmdElse.command_name, CmdElse.create, usage = 'ELSE')
CommandsFactory.register_command(CmdEndIf.command_name, CmdEndIf.create, usage = 'ENDIF')
CommandsFactory.register_command(CmdFor.command_name, CmdFor.create, usage = 'FOR I FROM 0 TO 100; FOR I FROM 100 TO 10 STEP 2;')
CommandsFactory.register_command(CmdNext.command_name, CmdNext.create, usage = 'NEXT I')
CommandsFactory.register_command(CmdPrint.command_name, CmdPrint.create, usage = 'PRINT $I; PRINT "Kraken"$1')
CommandsFactory.register_command(CmdPrint2File.command_name, CmdPrint2File.create, usage = 'PRINT2FILE filename, $I; PRINT2FILE filename, "Kraken"$1')
CommandsFactory.register_command(CmdStoreResult.command_name, CmdStoreResult.create, usage = 'STORE_RESULT result.csv')
CommandsFactory.register_command(CmdSet.command_name, CmdSet.create, usage = 'SET DB_PORT, 3306')
CommandsFactory.register_command(CmdRun.command_name, CmdRun.create, usage = 'RUN run_text.bat, 10; RUN net start RmiLink, 10')
CommandsFactory.register_command(CmdStartService.command_name, CmdStartService.create, usage = 'START_SERVICE Harmony')
CommandsFactory.register_command(CmdStopService.command_name, CmdStopService.create, usage = 'STOP_SERVICE Harmony')

