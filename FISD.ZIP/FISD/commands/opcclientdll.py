# -*- coding: utf-8 -*-
import time
import string
import socket
from ctypes import *
import os


class opcclient:

	def __init__ (self):
		"""
		"""
		self.opcclient = cdll.LoadLibrary("PyOPCClient.dll")
		if not self.opcclient:
			raise AttributeError, "Can't find/load PyOPCClient.dll; is it installed?"

	def __del__(self):
		"""
		"""
		pass

	def NumberOfOPCServers(self,opcenum,machinename):
		"""
		"""
		numofservers= self.opcclient.GetNumberOfServers(opcenum,machinename)
		return numofservers

	def GetOPCServerName(self,numofservers):
		"""
		"""
		serversname = []
		for index in range(numofservers):
			buffer = ' '*50
			stato = self.opcclient.GetServerName(index,buffer)
			nome = buffer[:string.find(buffer,'\0')]
			serversname.append(nome)
		return serversname

	def ConnectOPC (self,machinename,servername,mode=0):
		"""
		"""
		Num_Servers = self.NumberOfOPCServers(1,machinename)
		Server_Names = self.GetOPCServerName(Num_Servers)
		# mode = 0 execution
		# mode = 1 configuration
		self.handle = self.opcclient.OnConnect(mode,machinename,servername)
		return self.handle

	def SetParameters (self,mode=0,num_tag=1):
		"""
		"""
		# mode = 0 execution
		# mode = 1 configuration
		stato = self.opcclient.SetParameters(mode,num_tag)
		return stato

	def DisconnectOPC(self,hconnect):
		"""
		"""
		self.opcclient.OnDisconnect(hconnect)
		
	def GetServerStatus(self,hconnect):
		"""
		"""
		return self.opcclient.GetServerStatus(hconnect)

	def AddOPCGroup (self,hconnect,grpname,grprate,grpdeadband):
		"""
		"""
		grprate = int(grprate*1000)
		grpdeadband = int(grpdeadband)
		grp_handle = self.opcclient.AddGroup(hconnect,grpname,grprate,grpdeadband)
		return grp_handle

	def RemoveOPCGroup (self,hconnect,grp_handle):
		"""
		"""
		grp_handle = self.opcclient.RemoveGroup(hconnect,grp_handle)

	def NumberOfOPCItems (self,hconnect):
		"""
		"""
		NumTags = self.opcclient.NumTags(hconnect)
		return NumTags

	def GetOPCItemName(self,hconnect,numitems):
		"""
		"""
		itemsname = []
		index = 0
		buffer = ' '*100
		for index in range(numitems):
			stato = self.opcclient.GetItemName(hconnect,buffer,index)
			if stato == 0:
				nome = string.replace(buffer,'\x00','')
				itemsname.append(nome)

		return itemsname

	def GetOPCItemType(self,hconnect,hGroup,itemname):
		"""
		"""
		pVarType = ' '*8
		AccessRights = ' '*5
		stato = self.opcclient.GetItemType(hconnect,hGroup,itemname,pVarType,AccessRights)
		# stato = 0 item non trovato
		type = pVarType[:string.find(pVarType,'\0')]
		access = AccessRights[:string.find(AccessRights,'\0')]
		return stato,type,access

	def AddOPCItem(self,hconnect,hGroup,index,itemname):
		"""
		"""
		item_handle = self.opcclient.AddTag(hconnect,hGroup,index,itemname)
		return item_handle

	def RemoveOPCItem(self,hconnect,hGroup,index,itemhandle):
		"""
		"""
		stato = self.opcclient.RemoveTag(hconnect,hGroup,index,itemhandle)
		return stato

	def RemoveOPCAll(self,hconnect,hGroup,numtag):
		"""
		"""
		RemoveOPCItem =calldll.get_proc_address(self.opcclient,"RemoveAllTags")
		stato = calldll.call_foreign_function (RemoveOPCItem,'lll', 'l',
			(hconnect,hGroup,numtag))
		return stato

	def ReadOPCItem(self,hconnect,hGroup,index,num_previsto,syncro=0):
		"""
		"""
		buffer_tipo = ' '*10
		numero_elementi = ' '*10
		buffer_valore = ' '*2500
		buffer_qualita = ' '*10
		buffer_len = ' '*5
		
		# se non deve essere chiamata syncrona
		if syncro==0:
			stato = self.opcclient.ReadTagValue(index,buffer_tipo,buffer_valore,buffer_qualita,numero_elementi,buffer_len)
		else:
			stato = self.opcclient.ReadTagValueSincro(hconnect,hGroup,index,buffer_tipo,buffer_valore,buffer_qualita,numero_elementi,buffer_len)
		
		tipo = int(buffer_tipo[:string.find(buffer_tipo,'\0')])
		num_elementi = int(numero_elementi[:string.find(numero_elementi,'\0')])
		lunghezza = int(buffer_len[:string.find(buffer_len,'\0')])
		value = buffer_valore[:string.find(buffer_valore,'\0')]
		if num_elementi > 1:
			lista_valori = string.split(value,',')[:-1]
		else:
			lista_valori = [value]
		
		# se nei valori letti non compare la stringa ERRORE
		if 'ERRORE' not in lista_valori:
			quality = int(buffer_qualita[:string.find(buffer_qualita,'\0')])
		# assegno un quality non valido alla tag
		else:
			quality = 0
			
		# se si tratta di una stringa controllo che l'ultimo carattere non sia vuoto, se vuoto lo cancello
		if int(tipo)==8:
			for i in range(len(lista_valori)):
				val = lista_valori[i]
				if val[-1]==' ':
					lista_valori[i] = val[:-1]				
		
		# se la lettura 衳tata eseguita correttamente
		if stato==0:
			
			# controllo in caso di array che tutti i valori previsti siano arrivati e non meno
			if len(lista_valori)<num_previsto:
				# aggiungo dei valori nulli e forzo il quality a bad
				# se non si tratta di tipi stringhe
				if int(tipo)!=8:
					lista_valori += [0]*(num_previsto-len(lista_valori))
				else:
					lista_valori += ['']*(num_previsto-len(lista_valori))
				quality = 192
			
			# se il quality è tra i good/incerti lo forzo a valido
			if quality>=64:
				quality = 192
				
			# controllo il quality
			if quality not in [192]:
				stato = 3 + quality
			else:
				stato = 0
		# altrimenti scrivo lo stato di non ok
		else:
			stato = 2
		
		return stato,lista_valori,quality,tipo,num_elementi


	def WriteTagValue(self,hconnect,hGroup,index,value):
		"""
		"""
		stato = self.opcclient.WriteTagValue(hconnect,hGroup,index,value)
		return stato


	def GetOPCItemNumElem(self,hconnect,grp_handle,item):
		"""
		"""
		numero_elementi = self.opcclient.NumberOfItemElements(hconnect,grp_handle,item)
			
		return numero_elementi
