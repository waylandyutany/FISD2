from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from fisd_utils import *
import threading, time

########################################################################################################################
# CmdRunAsync
########################################################################################################################

class CmdRunAsync(Cmd):
    async_lock = threading.RLock()
    async_tasks = {}
    command_name = 'RUN_ASYNC'
    task_id_counter = 0

    def async_task_timeout():
        logger = logging.getLogger("fisd")
        while True:
            time.sleep(1)
            with CmdRunAsync.async_lock:
                for async_task in CmdRunAsync.async_tasks:
                    task, timeout, file = CmdRunAsync.async_tasks[async_task]
                    #print async_task, timeout
                    if timeout >= 0:
                        timeout -= 1
                        CmdRunAsync.async_tasks[async_task] = [task, timeout, file]
                        if timeout == -1:
                            logger.info("Killing async task '{0}' because of timeout.".format(async_task))
                            subprocess.Popen("TASKKILL /F /PID {pid} /T".format(pid=task.pid),
                                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    async_task_timeout_thread = threading.Thread(target=async_task_timeout)
    async_task_timeout_thread.daemon = True
    async_task_timeout_thread.start()

    @classmethod
    def create(cls, arguments):
        try:
            args = arguments.split(",")

            hide = False
            hide_param, i = parse_string(args[0])
            if hide_param.upper() == 'HIDE':
                hide = True
                args.pop(0)

            task_cmd, i = parse_string(args[0])
            task_timeout, i = parse_string(args[1])
            task_timeout = int(task_timeout)
            if len(args) > 2:
                task_id, i = parse_string(args[2])
            else:
                task_id = "task_id_" + str(cls.task_id_counter)
                cls.task_id_counter += 1

            return CmdRunAsync(hide, task_cmd, task_timeout, task_id)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        cmd = context._preprocess_variable(TestCasesPath.get_full_path(self.__task_cmd, context, False))
        std_out_file = None
        if self.__hide:
            std_out_file = open("out" + str(self.__task_id) + ".out", "w", 0)
            p = Popen(cmd, shell=True,stdout=std_out_file, stderr=std_out_file)
        else:
            p = Popen(cmd, shell=True)

        if self.__task_timeout > 0:
            context.logger().info("Running async task '{0}' with timeout {1} seconds. Task ID '{2}', Hide {3} ...".format(cmd,
                                                                                                             self.__task_timeout,
                                                                                                             self.__task_id,
                                                                                                             self.__hide))
            with CmdRunAsync.async_lock:
                CmdRunAsync.async_tasks[self.__task_id] = [p, self.__task_timeout, std_out_file]
        else:
            context.logger().info("Running async task '{0}' without timeout. Task ID '{1}', Hide {2} ...".format(cmd,
                                                                                                    self.__task_id,
                                                                                                    self.__hide))
            with CmdRunAsync.async_lock:
                CmdRunAsync.async_tasks[self.__task_id] = [p, -1, std_out_file]

    def __init__(self, hide, task_cmd, task_timeout, task_id):
        super(Cmd, self).__init__()
        self.__hide = hide
        self.__task_cmd = task_cmd
        self.__task_timeout = task_timeout
        self.__task_id = task_id

########################################################################################################################
# CmdStopAsync
########################################################################################################################
class CmdStopAsync(Cmd):
    command_name = 'STOP_ASYNC'

    @classmethod
    def create(cls, arguments):
        try:
            task_id, i = parse_string(arguments)
            return CmdStopAsync(task_id)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        if self.__task_id not in CmdRunAsync.async_tasks:
            context.logger().error("Unknown async task '{0}' to stop !".format(self.__task_id))
        else:
            context.logger().info("Stopping async task '{0}'.".format(self.__task_id))
            subprocess.Popen("TASKKILL /F /PID {pid} /T".format(pid=CmdRunAsync.async_tasks[self.__task_id][0].pid), stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
            with CmdRunAsync.async_lock:
                CmdRunAsync.async_tasks.pop(self.__task_id,None)

    def __init__(self, task_id):
        super(Cmd, self).__init__()
        self.__task_id = task_id

########################################################################################################################
# Commands registration
CommandsFactory.register_command(CmdRunAsync.command_name,
                                 CmdRunAsync.create,
                                 usage = 'RUN_ASYNC [HIDE], run_text.bat, 10, [task_id]; RUN_ASYNC net start RmiLink, 10, [task_id]',
                                 description = 'Running commands asynchronously')
CommandsFactory.register_command(CmdStopAsync.command_name,
                                 CmdStopAsync.create,
                                 usage='STOP_ASYNC task_id',
                                 description='Stopping async tas ran by RUN_ASYNC command')
