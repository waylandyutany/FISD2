from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from datetime import datetime, timedelta
import time

class CmdWait(Cmd):
    command_name = 'WAIT'

    @classmethod
    def create(cls, arguments):
        arguments = arguments.replace(' ','')
        dt = None
        try:
            dt = datetime.strptime(arguments,"%H:%M:%S")
        except:
            try:
                dt = datetime.strptime(arguments, "%M:%S")
            except:
                try:
                    dt = datetime.strptime(arguments, "%S")
                except:
                    raise_create_cmd_syntax_error(cls, arguments)

        return CmdWait(timedelta(hours=dt.hour,
                                 minutes=dt.minute,
                                 seconds=dt.second))

    def execute(self, context):
        super(Cmd, self).__init__()
        context.logger().info("Waiting {0} ...".format(str(self.__timedelta)))
        time.sleep(self.__timedelta.total_seconds())

    def __init__(self, timedelta):
        self.__timedelta = timedelta

CommandsFactory.register_command(CmdWait.command_name,CmdWait.create,usage = 'WAIT 00:00:01; WAIT 01:00; WAIT 1')
