from fisd_commands_factory import CommandsFactory
from file_commands import CmdSetTestCasesPath as TestCasesPath
from fisd_command import Cmd
from fisd_utils import *
import MySQLdb, os

def db_conf_from_context(context):
    return {
        'host' : context.get_variable('DB_URL'),
        'port' : int(context.get_variable('DB_PORT')),
        'user' : context.get_variable('DB_USER'),
        'password' : context.get_variable('DB_PASSWORD')
    }

def run_sql(db_name, query, db_conf):
    db_connection = MySQLdb.connect(host=db_conf["host"],
                                    port=db_conf["port"],
                                    user=db_conf["user"],
                                    passwd=db_conf["password"],
                                    db=db_name)
    db_connection.query(query)
    result = db_connection.store_result()
    ret = None
    if result is not None:
        ret = result.fetch_row(maxrows=0)
    db_connection.close()
    return ret

def database_exist(db_name, context):
    try:
        run_sql(db_name, "SHOW TABLES", db_conf_from_context(context))
    except:
        return False

    return True

########################################################################################################################
# CmdClearTable
########################################################################################################################
class CmdClearTable(Cmd):
    command_name = 'CLEAR_TABLE'

    @classmethod
    def create(cls, arguments):
        try:
            db_name, table_name = arguments.split('.')
            db_name, i = parse_string(db_name)
            table_name, i = parse_string(table_name)
            return CmdClearTable(db_name, table_name)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            if not database_exist(self.__db_name, context):
                context.logger().info("Database '{0}' does not exist !".format(self.__db_name))
                return

            run_sql(self.__db_name, "TRUNCATE TABLE {0}".format(self.__table_name), db_conf_from_context(context))
            context.logger().info("Database table '{0}'.'{1}' cleared.".format(self.__db_name,
                                                                               self.__table_name))
        except Exception as e:
            raise RuntimeError("Unable to clear '{0}'.'{1}' database table. {2}".format(self.__db_name,
                                                                         self.__table_name,
                                                                         str(e)))

    def __init__(self, db_name, table_name):
            super(Cmd, self).__init__()
            self.__db_name = db_name
            self.__table_name = table_name

########################################################################################################################
# CmdClearDatabase
########################################################################################################################
class CmdClearDatabase(Cmd):
    command_name = 'CLEAR_DB'

    @classmethod
    def create(cls, arguments):
        try:
            db_name, i = parse_string(arguments)
            return CmdClearDatabase(db_name)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            if not database_exist(self.__db_name, context):
                context.logger().info("Database '{0}' does not exist !".format(self.__db_name))
                return

            tables = run_sql(self.__db_name, "SHOW TABLES", db_conf_from_context(context))
            for table in tables:
                table_name = table[0]
                run_sql(self.__db_name, "TRUNCATE TABLE {0}".format(table_name), db_conf_from_context(context))

            context.logger().info("Database '{0}' cleared.".format(self.__db_name))
        except Exception as e:
            raise RuntimeError("Unable to clear '{0}' database. {1}".format(self.__db_name, str(e)))

    def __init__(self, db_name):
        super(Cmd, self).__init__()
        self.__db_name = db_name

########################################################################################################################
# CmdDropTable
########################################################################################################################
class CmdDropTable(Cmd):
    command_name = 'DROP_TABLE'

    @classmethod
    def create(cls, arguments):
        try:
            db_name, table_name = arguments.split('.')
            db_name, i = parse_string(db_name)
            table_name, i = parse_string(table_name)
            return CmdDropTable(db_name, table_name)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            if not database_exist(self.__db_name, context):
                context.logger().info("Database '{0}' does not exist !".format(self.__db_name))
                return

            run_sql(self.__db_name, "DROP TABLE IF EXISTS {0}".format(self.__table_name), db_conf_from_context(context))
            context.logger().info("Database table '{0}'.'{1}' droped.".format(self.__db_name,
                                                                               self.__table_name))
        except Exception as e:
            raise RuntimeError("Unable to drop '{0}'.'{1}' database table. {2}".format(self.__db_name,
                                                                                        self.__table_name,
                                                                                        str(e)))

    def __init__(self, db_name, table_name):
        super(Cmd, self).__init__()
        self.__db_name = db_name
        self.__table_name = table_name

########################################################################################################################
# CmdDropDatabase
########################################################################################################################
class CmdDropDatabase(Cmd):
    command_name = 'DROP_DB'

    @classmethod
    def create(cls, arguments):
        try:
            db_name, i = parse_string(arguments)
            return CmdDropDatabase(db_name)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            if not database_exist(self.__db_name, context):
                context.logger().info("Database '{0}' does not exist !".format(self.__db_name))
                return

            tables = run_sql(self.__db_name, "SHOW TABLES", db_conf_from_context(context))
            for table in tables:
                table_name = table[0]
                run_sql(self.__db_name, "DROP TABLE IF EXISTS {0}".format(table_name), db_conf_from_context(context))

            context.logger().info("Database '{0}' droped.".format(self.__db_name))
        except Exception as e:
            raise RuntimeError("Unable to drop '{0}' database. {1}".format(self.__db_name,
                                                                           str(e)))

    def __init__(self, db_name):
        super(Cmd, self).__init__()
        self.__db_name = db_name

########################################################################################################################
# CmdRunQuery
########################################################################################################################
class CmdRunQuery(Cmd):
    command_name = 'RUN_QUERY'

    @classmethod
    def create(cls, arguments):
        try:
            coma_index = arguments.find(",")
            if coma_index < 1:
                raise
            db_name, i = parse_string(arguments[:coma_index])
            query, i = parse_string(arguments[coma_index + 1:])
            return CmdRunQuery(db_name, query)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        try:
            query = self.__query
            try:
                query_file_name = TestCasesPath.get_full_path(self.__query, context, False)
                with open(query_file_name, 'r') as f:
                    context.logger().info("Loading query  from '{0}'".format(query_file_name))
                    query = f.read()
            except:
                pass

            query = context._preprocess_variable(query)

            context.logger().info("Database '{0}' is running query : '{1}'".format(self.__db_name,
                                                                     query))
            res = run_sql(self.__db_name, query, db_conf_from_context(context))
            if res is not None:
                context.store_execution_result(res)
                #context.logger().info("Database '{0}' query results : {1}".format(self.__db_name,
                #                                                         str(res)))
            else:
                context.logger().info("Database '{0}' query success.".format(self.__db_name))

        except Exception as e:
            raise RuntimeError("Database '{0}' unable to run query '{1}'. {2}".format(self.__db_name,
                                                                               self.__query,
                                                                               str(e)))

    def __init__(self, db_name, query):
        super(Cmd, self).__init__()
        self.__db_name = db_name
        self.__query = query

########################################################################################################################
# Commands registration
########################################################################################################################
CommandsFactory.register_command(CmdClearTable.command_name,
                                 CmdClearTable.create,
                                 usage = "CLEAR_TABLE histery.allarmi",
                                 description = 'Clear database table')

CommandsFactory.register_command(CmdClearDatabase.command_name,
                                 CmdClearDatabase.create,
                                 usage='CLEAR_DB histery',
                                 description='Clear all tables in database')

CommandsFactory.register_command(CmdDropTable.command_name,
                                 CmdDropTable.create,
                                 usage='DROP_TABLE histery.allarmi',
                                 description='Drop table from database')

CommandsFactory.register_command(CmdDropDatabase.command_name,
                                 CmdDropDatabase.create,
                                 usage='DROP_DB histery',
                                 description='Drop database')

CommandsFactory.register_command(CmdRunQuery.command_name,
                                 CmdRunQuery.create,
                                 usage='RUN_QUERY history, select * from histery.allarmi; RUN_QUERY histery, query.txt',
                                 description='Run database query')
