from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
import paramiko

class CmdRunSSHCmd(Cmd):
    command_name = 'RUN_SSH_CMD'
    ssh = None

    @classmethod
    def create(cls, arguments):
        return CmdRunSSHCmd(arguments)

    def execute(self, context):
        server = None
        username = None
        password = None
        ssh_command = ""

        args = context.parse_arguments(self.__arguments)
        #noblock
        noblock = False
        for i in range(0,len(args)):
            if str(args[i]).lower() == 'noblock':
                args.pop(i)
                noblock = True
                break

        if len(args) == 2:
            server, ssh_command = args
        elif len(args) == 4:
            server, username, password, ssh_command = args
        elif len(args) == 1:
            ssh_command, = args
        else:
            raise_create_cmd_syntax_error(CmdRunSSHCmd, self.__arguments)

        context.logger().info(CmdRunSSHCmd.command_name + " " + ",".join(args))
        try:
            if username != None or password != None or CmdRunSSHCmd.ssh == None:
                CmdRunSSHCmd.ssh = paramiko.SSHClient()
                CmdRunSSHCmd.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                CmdRunSSHCmd.ssh.connect(server, username=username, password=password)
            ssh_stdin, ssh_stdout, ssh_stderr = CmdRunSSHCmd.ssh.exec_command(ssh_command, get_pty = True)
            if not noblock:
                context.logger().info(str(ssh_stdout.read()))
                context.logger().info(str(ssh_stderr.read()))
        except Exception as e:
            context.logger().error(str(e))

    def __init__(self, arguments):
        self.__arguments = arguments

CommandsFactory.register_command(CmdRunSSHCmd.command_name,CmdRunSSHCmd.create,usage = 'RUN_SSH_CMD address, user, pwd, cmd, noblock;RUN_SSH_CMD address, cmd ')
