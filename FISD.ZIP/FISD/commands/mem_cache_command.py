from fisd_commands_factory import CommandsFactory
from fisd_command import Cmd
from fisd_utils import *
import os, memcache, memcached_stats
from subprocess import Popen
from memcached_stats import MemcachedStats

nl = '\n'

def print_structured(f,  mc, keys, space = ''):
    if not keys:
        return

    if not isinstance(keys, dict):
        f.write(space + str(keys) + nl)
        return

    for key in keys:
        f.write(space + str(key) + nl)
        tmp_keys = keys[key]
        print_structured(f, mc, tmp_keys, space + '    ')

def SNAPSHOT(context, arguments):  # output_file_name
    mc_ip = context.get_variable('MEMCACHE_IP')
    mc_port = context.get_variable('MEMCACHE_PORT')
    output_file_name = os.path.join(context.get_variable('TEST_CASES_PATH'), arguments)

    context.logger().info("Memcache '{0}':{1} snapshoting to '{2}'".format(mc_ip, mc_port, output_file_name))

    mc_stats = MemcachedStats(mc_ip, mc_port)
    mc = memcache.Client([str(mc_ip) + ':' + str(mc_port)], debug=0)

    stats = mc_stats.stats()
    with open(output_file_name,'w') as f:
        f.write( "Memcache server stats :" + nl )
        f.write(str(stats) + nl)
        f.write( "Memcache server snapshot :" + nl )
        for key in mc_stats.keys():
            f.write(str(key) + nl)
            print_structured(f, mc, mc.get(key), '    ')

    context.logger().info("Memcache '{0}':{1} snapshot saved to '{2}'".format(mc_ip, mc_port, output_file_name))


def START(context, arguments):
    context.logger().info("Starting memcache")
    Popen(context.get_variable('MEMCACHE_EXECUTABLE'))

def STOP(context, arguments):
    context.logger().info("Stopping memcache")
    os.system("Taskkill /F /IM memcached.exe")

def RESTART(context, arguments):
    context.logger().info("Restarting memcache...")
    STOP(context, arguments)
    START(context, arguments)

########################################################################################################################
# CmdMemCache
########################################################################################################################
class CmdMemCache(Cmd):
    command_name = 'MEMCACHE'

    registered_commands = {'SNAPSHOT': SNAPSHOT,
                           'START': START,
                           'STOP': STOP,
                           'RESTART': RESTART,
                           }
    @classmethod
    def create(cls, arguments):
        try:
            for cmd in cls.registered_commands:
                if arguments.startswith(cmd):
                    command = cmd
                    args, i = parse_string(arguments[len(command):])
                    return CmdMemCache(command, args)
            raise_create_cmd_syntax_error(cls, arguments)
        except:
            raise_create_cmd_syntax_error(cls, arguments)

    def execute(self, context):
        command_func = CmdMemCache.registered_commands[self.__command]
        command_func(context, self.__arguments)

    def __init__(self, command, arguments):
        super(Cmd, self).__init__()
        self.__command = command
        self.__arguments = arguments

########################################################################################################################
# Commands registration
CommandsFactory.register_command(CmdMemCache.command_name,
                                 CmdMemCache.create,
                                 usage = 'MEMCACHE SNAPSHOT "output_file_name"; MEMCACHE START; MEMCACHE STOP; MEMCACHE RESTART;',
                                 description = 'Mem cache related functionality')
