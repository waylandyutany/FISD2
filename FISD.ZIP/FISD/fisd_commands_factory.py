class CommandsFactory:
    registered_commands = { }
    parsed_commands = {}
    default_commands_directory = ""

    @classmethod
    def register_command(cls, cmd, creator, usage = '', description = ''):
        cls.registered_commands[cmd.upper()] = {'creator' : creator,
                                                       'usage' : usage,
                                                       'description' : description}

    @staticmethod
    def remove_comments_and_line_ending(line):
        line = line.replace('\r','').replace('\n','')
        sharp_index = line.find('#')
        if sharp_index >= 0:
            return line[:sharp_index].lstrip()
        return line.lstrip()

    @classmethod
    def parse_and_create_command(cls, line, commands):
        ln = cls.remove_comments_and_line_ending(line)
        if ln == '':
            return

        cmd = ln
        space_index = ln.find(' ')
        if space_index > 0:
            cmd = ln[:space_index]
        cmd_upper = str(cmd).upper()

        if cmd_upper not in cls.registered_commands:
            raise SyntaxError("Unknown command '{0}'".format(cmd))
        arguments = ln[len(cmd_upper):]

        cmd_object = cls.registered_commands[cmd_upper]['creator'](arguments.lstrip())
        if cmd_object is not None:
            cmd_object.set_name(cmd_upper)
            commands.append(cmd_object)

    @classmethod
    def get_property(cls, cmd_name, property):
        if cmd_name not in cls.registered_commands:
            return None
        if property not in cls.registered_commands[cmd_name]:
            return None
        return cls.registered_commands[cmd_name][property]

    @classmethod
    def print_registered_commands(cls, logger):
        for cmd in cls.registered_commands:
            logger.info("'{0}' : {1}".format(cmd, cls.registered_commands[cmd]['description']))
            logger.info("    Usage : {0}".format(cls.registered_commands[cmd]['usage']))

    @classmethod
    def parse_commands(cls, fisd_file):
        if fisd_file in cls.parsed_commands:
            return cls.parsed_commands[fisd_file], 0

        commands = []
        number_errors = 0
        line_number = 0
        with open(fisd_file, "r") as lines:
            for line in lines:
                try:
                    CommandsFactory.parse_and_create_command(line, commands)
                except SyntaxError as e:
                    import logging
                    logger = logging.getLogger("fisd")
                    number_errors += 1
                    logger.error("'{2}' : [{0}] : {1}".format(str(line_number + 1), str(e), fisd_file))
                line_number += 1

        if number_errors == 0:
            cls.parsed_commands[fisd_file] = commands

        return commands, number_errors
