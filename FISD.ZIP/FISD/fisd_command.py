from fisd_commands_factory import CommandsFactory

class Cmd(object):
    def __init__(self):
        self.__name = None

    def execute(self, context):
        raise NotImplementedError

    def set_name(self,name):
        self.__name = name

    def get_name(self):
        return self.__name

    def __str__(self):
        return self.__name

    def get_property(self, property):
        return CommandsFactory.get_property(self.get_name(), property)