import sys, logging, imp, os, traceback, json
from logging.handlers import RotatingFileHandler

# todos
# Use context.parse_arguments for other commands
# Modify for for other then float numbers (date time)

__version__ = 2.0

commands_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'commands/')
sys.path.insert(0, '\\')
sys.path.insert(1, commands_path)

from fisd_commands_factory import CommandsFactory
from fisd_context import Context

# todo use shared iim_config module
def load_module_cfg():
    module_cfg_files = ['d:/config/fisd_conf.json', 'c:/config/fisd_conf.json']
    for module_cfg in module_cfg_files:
        if os.path.isfile(module_cfg):
            with open(module_cfg) as data_file:
                return json.load(data_file)
    return None

def initialize_logger():
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    log_level = logging.DEBUG

    log_path = "./fisd_log.txt"
    log_size_mb = 5
    log_backup_number = 2
    #log_verbosity
    logger_verbose_table = {
        "CRITICAL": logging.CRITICAL,
        "ERROR": logging.ERROR,
        "WARNING": logging.WARNING,
        "INFO": logging.INFO,
        "DEBUG": logging.DEBUG
    }

    module_cfg = load_module_cfg()
    if module_cfg:
        if 'log_path' in module_cfg:
            log_path = module_cfg['log_path']
        if 'log_size_mb' in module_cfg:
            log_size_mb = module_cfg['log_size_mb']
        if 'log_backup_number' in module_cfg:
            log_backup_number = module_cfg['log_backup_number']
        if 'log_verbosity' in module_cfg:
            log_level = logger_verbose_table[module_cfg['log_verbosity'].upper()]

    logger = logging.getLogger("fisd")
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    rotating_file_handler = RotatingFileHandler(log_path,
                                                maxBytes=log_size_mb * 1024 * 1024,
                                                backupCount=log_backup_number)
    rotating_file_handler.setFormatter(formatter)
    logger.addHandler(rotating_file_handler)
    logger.addHandler(stream_handler)
    logger.setLevel(log_level)
    return logger

def load_commands(commands_path):
    ignore_files = ['__init__.py']
    for name in os.listdir(commands_path):
        if name.endswith('.py') and name not in ignore_files:
            logger.info("Loading command file '{0}'".format(name))
            imp.load_source(__name__, os.path.join(commands_path, name))

def fill_default_variables(context):
    context.logger().info("Setting default variables")
    context.set_variable('DB_URL', '127.0.0.1')
    context.set_variable('DB_PORT', 3306)
    context.set_variable('DB_USER', 'fdsdriver')
    context.set_variable('DB_PASSWORD', 'fdscollector')
    context.set_variable('TEST_CASES_PATH', '..')
    context.set_variable('OPC_CLIENT_NAME', 'OPC_Client_3_0.exe')
    context.set_variable('RMI_LINK_INI_PATH', 'd:/inspiring/rmilink/RmiLink.ini')
    context.set_variable('MEMCACHE_IP', '127.0.0.1')
    context.set_variable('MEMCACHE_PORT', 11211)

    module_cfg = load_module_cfg()
    if module_cfg:
        context.logger().info("Setting variables from module config file")
        if 'variables' in module_cfg:
            for variable in module_cfg['variables']:
                name = variable['name']
                value = variable['value']
                context.set_variable(name, value)

if __name__=='__main__':
    logger = initialize_logger()

    try:
        load_commands(commands_path)

        # -h command handling
        if len(sys.argv) == 2 and sys.argv[1] in ['-h', '-?']:
            CommandsFactory.print_registered_commands(logger)
            sys.exit()

        # fisd file cmd line argument check
        if len(sys.argv) < 2:
            logger.error("You must provide fisd file with commands for interpretation or -h for help !")
            sys.exit()

        command_file_name = sys.argv[1]
        CommandsFactory.default_commands_directory, cmd_file_name = os.path.split(command_file_name)

        commands, number_errors = CommandsFactory.parse_commands(sys.argv[1])

        if number_errors > 0:
            logger.error("Please fix all {0} errors before execution !".format(str(number_errors)))
            sys.exit()

        context = Context(logger)
        fill_default_variables(context)
        context.execute_commands(commands)
    except Exception as e:
        logger.critical(str(e) + " - " + str(sys.exc_info()))
        exc_type, exc_value, exc_traceback = sys.exc_info()
        for trace_line in traceback.format_exception(exc_type, exc_value, exc_traceback):
            logger.critical(str(trace_line)[:-1])
        raise

